sudo python3 setup.py develop
tar xJf benchmarks.tar.xz
