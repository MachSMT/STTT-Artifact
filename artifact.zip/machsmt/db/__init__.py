from .db import DB
database = DB()