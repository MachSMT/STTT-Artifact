class MachSMTException(Exception):
    pass